package com.dp360crm.model;

public class CrmLandingPage {

}
